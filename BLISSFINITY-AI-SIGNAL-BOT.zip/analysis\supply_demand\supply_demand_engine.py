import pandas as pd


def detect_supply_demand(df: pd.DataFrame):
    """
    Detect simple supply and demand zones.
    """

    if len(df) < 20:
        return {
            "demand_zone": None,
            "supply_zone": None,
            "bias": "UNKNOWN",
        }

    demand = float(df["low"].tail(20).min())
    supply = float(df["high"].tail(20).max())
    current = float(df["close"].iloc[-1])

    if current < (demand + supply) / 2:
        bias = "BUY"

    else:
        bias = "SELL"

    return {
        "demand_zone": round(demand, 4),
        "supply_zone": round(supply, 4),
        "bias": bias,
    }