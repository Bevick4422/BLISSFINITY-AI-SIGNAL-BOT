"""
Smart Money Concepts (SMC) Engine

Detects:
- Order Blocks
- Fair Value Gaps (FVG)
"""

import pandas as pd


def detect_smc(df: pd.DataFrame):
    """
    Detect basic Smart Money Concepts.

    Returns:
    {
        "bullish_order_block": bool,
        "bearish_order_block": bool,
        "bullish_fvg": bool,
        "bearish_fvg": bool
    }
    """

    if len(df) < 4:
        return {
            "bullish_order_block": False,
            "bearish_order_block": False,
            "bullish_fvg": False,
            "bearish_fvg": False,
        }

    prev = df.iloc[-2]
    curr = df.iloc[-1]
    older = df.iloc[-3]

    bullish_order_block = (
        prev["close"] < prev["open"]
        and curr["close"] > curr["open"]
        and curr["close"] > prev["high"]
    )

    bearish_order_block = (
        prev["close"] > prev["open"]
        and curr["close"] < curr["open"]
        and curr["close"] < prev["low"]
    )

    bullish_fvg = curr["low"] > older["high"]

    bearish_fvg = curr["high"] < older["low"]

    return {
        "bullish_order_block": bullish_order_block,
        "bearish_order_block": bearish_order_block,
        "bullish_fvg": bullish_fvg,
        "bearish_fvg": bearish_fvg,
    }