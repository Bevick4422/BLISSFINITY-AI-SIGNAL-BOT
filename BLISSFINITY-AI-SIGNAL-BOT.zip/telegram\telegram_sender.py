import requests

from config.settings import TELEGRAM_TOKEN, TELEGRAM_CHAT_ID
from telegram.formatter import format_signal


def send_signal(signal: dict):

    text = format_signal(signal)

    url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"

    payload = {
        "chat_id": TELEGRAM_CHAT_ID,
        "text": text
    }

    try:
        requests.post(url, json=payload, timeout=10)
        print("Telegram signal sent.")
    except Exception as e:
        print(f"Telegram Error: {e}")