"""
BLISSFINITY AI SIGNAL BOT
RISK ENGINE
"""

from typing import Dict


def calculate_risk(
    entry: float,
    atr: float,
    direction: str = "BUY",
    rr: float = 3.0
) -> Dict:

    if direction == "BUY":

        stop_loss = entry - (atr * 1.5)
        take_profit = entry + ((entry - stop_loss) * rr)

    else:

        stop_loss = entry + (atr * 1.5)
        take_profit = entry - ((stop_loss - entry) * rr)

    risk = abs(entry - stop_loss)
    reward = abs(take_profit - entry)

    return {

        "entry": round(entry, 8),
        "stop_loss": round(stop_loss, 8),
        "take_profit": round(take_profit, 8),
        "risk": round(risk, 8),
        "reward": round(reward, 8),
        "rr": round(reward / risk, 2)

    }