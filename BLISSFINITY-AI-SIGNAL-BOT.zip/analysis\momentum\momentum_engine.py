"""
BLISSFINITY Momentum Engine
"""

import pandas as pd


def analyze_momentum(df: pd.DataFrame):
    """
    Analyze market momentum.

    Returns:
    {
        "momentum": "BULLISH" | "BEARISH" | "NEUTRAL",
        "strength": int
    }
    """

    if len(df) < 20:
        return {
            "momentum": "NEUTRAL",
            "strength": 0
        }

    ema20 = df["close"].ewm(span=20).mean()

    current = df["close"].iloc[-1]

    if current > ema20.iloc[-1]:
        return {
            "momentum": "BULLISH",
            "strength": 100
        }

    if current < ema20.iloc[-1]:
        return {
            "momentum": "BEARISH",
            "strength": 100
        }

    return {
        "momentum": "NEUTRAL",
        "strength": 0
    }