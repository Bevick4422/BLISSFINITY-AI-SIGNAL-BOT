import ccxt
import os
import pandas as pd
from dotenv import load_dotenv

load_dotenv()

EXCHANGE_NAME = os.getenv("EXCHANGE", "mexc").lower()
DEFAULT_TIMEFRAME = os.getenv("DEFAULT_TIMEFRAME", "15m")
OHLCV_LIMIT = int(os.getenv("OHLCV_LIMIT", "500"))


def get_exchange():
    exchanges = {
        "mexc": ccxt.mexc,
        "binance": ccxt.binance,
        "bybit": ccxt.bybit,
    }

    exchange_class = exchanges.get(EXCHANGE_NAME)

    if exchange_class is None:
        raise ValueError(f"Unsupported exchange: {EXCHANGE_NAME}")

    return exchange_class({
        "enableRateLimit": True,
    })


exchange = get_exchange()


def fetch_market_data(symbol="BTC/USDT",
                      timeframe=DEFAULT_TIMEFRAME,
                      limit=OHLCV_LIMIT):
    """
    Download OHLCV candles.
    """

    exchange.load_markets()

    candles = exchange.fetch_ohlcv(
        symbol,
        timeframe=timeframe,
        limit=limit
    )

    df = pd.DataFrame(
        candles,
        columns=[
            "timestamp",
            "open",
            "high",
            "low",
            "close",
            "volume",
        ],
    )

    df["timestamp"] = pd.to_datetime(
        df["timestamp"],
        unit="ms"
    )

    return df