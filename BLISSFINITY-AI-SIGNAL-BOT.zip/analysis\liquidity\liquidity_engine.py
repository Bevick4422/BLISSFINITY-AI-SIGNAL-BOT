"""
BLISSFINITY Liquidity Engine
Detects liquidity grabs (stop hunts).
"""

import pandas as pd


def detect_liquidity_grab(df: pd.DataFrame):
    """
    Returns a standardized liquidity grab object.
    """

    if len(df) < 5:
        return {
            "grab": None,
            "strength": 0,
            "liquidity_sweep_high": False,
            "liquidity_sweep_low": False,
        }

    recent_high = df["high"].iloc[-5:-1].max()
    recent_low = df["low"].iloc[-5:-1].min()

    current_high = df["high"].iloc[-1]
    current_low = df["low"].iloc[-1]

    sweep_high = current_high > recent_high
    sweep_low = current_low < recent_low

    if sweep_low:
        grab = "BUY"
    elif sweep_high:
        grab = "SELL"
    else:
        grab = None

    strength = 100 if grab else 0

    return {
        "grab": grab,
        "strength": strength,
        "liquidity_sweep_high": sweep_high,
        "liquidity_sweep_low": sweep_low,
    }