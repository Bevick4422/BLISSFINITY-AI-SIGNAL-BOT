import pandas as pd


def detect_structure(df: pd.DataFrame):
    """
    Detect market structure.

    Returns:
        {
            "trend_structure": "...",
            "bos": bool,
            "choch": bool
        }
    """

    if len(df) < 10:
        return {
            "trend_structure": "UNKNOWN",
            "bos": False,
            "choch": False
        }

    highs = df["high"].tail(6).tolist()
    lows = df["low"].tail(6).tolist()

    higher_high = highs[-1] > highs[-2]
    higher_low = lows[-1] > lows[-2]

    lower_high = highs[-1] < highs[-2]
    lower_low = lows[-1] < lows[-2]

    structure = "RANGE"

    if higher_high and higher_low:
        structure = "BULLISH"

    elif lower_high and lower_low:
        structure = "BEARISH"

    bos = False
    choch = False

    if structure == "BULLISH":
        bos = highs[-1] > max(highs[:-1])

    if structure == "BEARISH":
        bos = lows[-1] < min(lows[:-1])

    if structure == "RANGE":
        choch = True

    return {
        "trend_structure": structure,
        "bos": bos,
        "choch": choch
    }