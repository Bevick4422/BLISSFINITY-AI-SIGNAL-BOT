import asyncio
import pandas as pd

from scanner.market_scanner import get_market_data
from signal_engine import generate_signal

from telegram.sender import send_signal

SYMBOLS = [
    "BTCUSDT",
    "ETHUSDT",
    "SOLUSDT"
]


async def run():

    while True:

        for symbol in SYMBOLS:

            try:

                df = get_market_data(symbol)

                signal = generate_signal(df)

                if signal:

                    await send_signal(signal)

                    print(f"{symbol} Signal Sent")

                else:

                    print(f"{symbol} No Signal")

            except Exception as e:

                print(symbol, e)

        await asyncio.sleep(60)


if __name__ == "__main__":

    asyncio.run(run())