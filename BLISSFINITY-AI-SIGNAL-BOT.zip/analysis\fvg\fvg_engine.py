import pandas as pd


def detect_fvg(df: pd.DataFrame):

    """
    Detects the most recent bullish or bearish Fair Value Gap.
    """

    if len(df) < 5:
        return {
            "type": None,
            "top": None,
            "bottom": None
        }

    # Bullish FVG
    if df["low"].iloc[-1] > df["high"].iloc[-3]:

        return {
            "type": "BULLISH",
            "top": float(df["low"].iloc[-1]),
            "bottom": float(df["high"].iloc[-3])
        }

    # Bearish FVG
    if df["high"].iloc[-1] < df["low"].iloc[-3]:

        return {
            "type": "BEARISH",
            "top": float(df["low"].iloc[-3]),
            "bottom": float(df["high"].iloc[-1])
        }

    return {
        "type": None,
        "top": None,
        "bottom": None
    }