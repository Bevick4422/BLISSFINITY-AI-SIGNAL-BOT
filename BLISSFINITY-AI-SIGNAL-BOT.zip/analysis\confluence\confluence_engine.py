"""
BLISSFINITY AI SIGNAL BOT
CONFLUENCE ENGINE
"""

from typing import Dict


def calculate_confluence(
    trend: Dict,
    structure: Dict,
    liquidity: Dict,
    smc: Dict,
    wave: Dict,
    momentum: Dict
):

    score = 0

    # Trend
    if trend.get("trend") == "BULLISH":
        score += 20
    elif trend.get("trend") == "BEARISH":
        score += 20

    # Structure
    if structure.get("bos"):
        score += 20

    # Liquidity
    if liquidity.get("sweep"):
        score += 15

    # SMC
    if smc.get("bullish_order_block"):
        score += 15

    if smc.get("bearish_order_block"):
        score += 15

    if smc.get("bullish_fvg"):
        score += 10

    if smc.get("bearish_fvg"):
        score += 10

    # Elliott Wave
    if wave.get("wave") == "IMPULSE":
        score += 10

    # Momentum
    if momentum.get("momentum") == "BULLISH":
        score += 10

    if momentum.get("momentum") == "BEARISH":
        score += 10

    score = min(score, 100)

    if score >= 80:
        confidence = "HIGH"
    elif score >= 60:
        confidence = "MEDIUM"
    else:
        confidence = "LOW"

    if trend.get("trend") == "BULLISH":
        signal = "BUY"
    elif trend.get("trend") == "BEARISH":
        signal = "SELL"
    else:
        signal = "NONE"

    return {
        "score": score,
        "confidence": confidence,
        "signal": signal
    }