from analysis.trend.trend_engine import detect_trend
from analysis.structure.structure_engine import detect_structure
from analysis.liquidity.liquidity_engine import detect_liquidity

from analysis.wave.wave_engine import detect_wave
from analysis.confluence.confluence_engine import calculate_confluence
from analysis.risk.risk_engine import calculate_trade_levels

from telegram.formatter import format_signal


def generate_signal(df):

    trend = detect_trend(df)

    structure = detect_structure(df)

    liquidity = detect_liquidity(df)

    wave = detect_wave(df)

    confluence = calculate_confluence(
        trend,
        structure,
        liquidity,
        wave
    )

    if confluence["signal"] == "NONE":
        return None

    trade = calculate_trade_levels(
        df,
        confluence["signal"]
    )

    return format_signal(
        symbol="BTCUSDT",
        side=confluence["signal"],
        entry=trade["entry"],
        stop=trade["stop_loss"],
        target=trade["take_profit"],
        rr=trade["rr"]
    )