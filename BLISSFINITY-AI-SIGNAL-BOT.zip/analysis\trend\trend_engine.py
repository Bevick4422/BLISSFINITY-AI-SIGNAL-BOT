import pandas as pd


def detect_trend(df):
    """
    Detect trend using EMA50 and EMA200.
    """

    df = df.copy()

    df["EMA50"] = df["close"].ewm(span=50).mean()
    df["EMA200"] = df["close"].ewm(span=200).mean()

    last = df.iloc[-1]

    if last["EMA50"] > last["EMA200"]:
        return "Bullish"

    if last["EMA50"] < last["EMA200"]:
        return "Bearish"

    return "Neutral"