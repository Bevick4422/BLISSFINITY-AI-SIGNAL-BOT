"""
BLISSFINITY SIGNAL FORMATTER
"""

def format_signal(signal):

    return f"""
🟢 BLISSFINITY AI SIGNAL

PAIR:
{signal["pair"]}

SIDE:
{signal["side"]}

ENTRY:
{signal["entry"]}

STOP:
{signal["stop_loss"]}

TARGET:
{signal["take_profit"]}

RR:
{signal["rr"]}
""".strip()