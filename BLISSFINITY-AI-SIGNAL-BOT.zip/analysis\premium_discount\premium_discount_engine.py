"""
BLISSFINITY PREMIUM / DISCOUNT ENGINE
"""


def detect_premium_discount(df):

    highest = df["high"].max()
    lowest = df["low"].min()

    equilibrium = (highest + lowest) / 2

    current = float(df["close"].iloc[-1])

    if current < equilibrium:
        zone = "DISCOUNT"

    elif current > equilibrium:
        zone = "PREMIUM"

    else:
        zone = "EQUILIBRIUM"

    return {

        "zone": zone,
        "equilibrium": equilibrium,
        "price": current

    }